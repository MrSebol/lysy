Create Database dziennik17;
Use dziennik17;
Create Table uczniowie( ID INT PRIMARY KEY AUTO_INCREMENT, imie Varchar(30), nazwisko Varchar(30), email Varchar(100), wiek INT(3));

Insert Into uczniowie (imie, nazwisko, email, wiek) Values('Jan', 'Kowalski', 'jank@wp.pl', '15'),
('Piotr','Nowak','Pnowak@o2.pl','23'),
('Osakr','Pas', 'Opas@wp.pl', '33'),
('Olaf', 'Uras', 'Olafura@gmail.com', '41'),
('Magda', 'Kowalska', 'Magdkow@o2.pl', '32'),
('Konrad', 'alien', 'Konradal@o2.pl', '22'),
('Andrzej', 'Nowak', 'Anowak@wp.pl', '52'),
('Anna', 'Most', 'AnnaM@o2.pl', '40'),
('Józef', 'Olg', 'JózefO@wp.pl', '19'),
('Franek', 'Baran', 'FranekBaran@gmail.com', '16');