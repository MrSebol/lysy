<?php

$conn = mysqli_connect("localhost", "root", "", "dziennik17");


if (isset($_POST['imie'])) {
    $imie = $_POST['imie'];
    $nazwisko = $_POST['nazwisko'];
    $email =  $_POST['email'];
    $wiek = $_POST['wiek'];



    mysqli_query($conn, "INSERT INTO uczniowie (imie, nazwisko, email, wiek) VALUES ('$imie', '$nazwisko', '$email', '$wiek')");
    echo "Dodany <br>";
}


if (isset($_POST['id'])) {
    $id = $_POST['id'];


    mysqli_query($conn, "DELETE FROM uczniowie WHERE id = $id");
    echo "Uczeń usunięty!<br>";
}
?>


<h2>Dodaj ucznia</h2>
<form method="POST">
    Imię: <input type="text" name="imie" required><br>
    nazwisko <input type="text" name="nazwisko" required> <br>
    email <input type="text" name="email" required> <br>
    Wiek: <input type="number" name="wiek" required><br>

    <input type="submit" value="Dodaj ucznia">
</form>


<h2>Usuń ucznia</h2>
<form method="POST">
    ID ucznia: <input type="number" name="id" required><br>
    <input type="submit" value="Usuń ucznia">
</form>


<h2>Lista </h2>
<?php

$result = mysqli_query($conn, "SELECT * FROM uczniowie");


while ($row = mysqli_fetch_assoc($result)) {
    echo " | Imię: " . $row['imie'] . " | Nazwisko: " . $row['nazwisko'] . " | email: " . $row['email'] . " | Wiek: " . $row['wiek'] . "<br>";
}
?>